/*
 * Mause ESP32 - Air mouse (Bluetooth LE o WiFi)
 * Placa:   Seeed XIAO ESP32-S3
 * Sensor:  MPU-6050 (I2C, dirección 0x68)
 *
 * Conexiones:
 *   MPU-6050 VCC -> 3V3        MPU-6050 GND -> GND
 *   MPU-6050 SCL -> D5 (GPIO6) MPU-6050 SDA -> D4 (GPIO5)
 *   Botón izquierdo -> D0 (GPIO1) a GND
 *   Botón derecho   -> D1 (GPIO2) a GND
 *
 * MODOS (elige uno en MODO, más abajo):
 *   MODO_BLE  : ratón Bluetooth LE estándar. El PC/móvil lo ve como un ratón
 *               normal, sin programas extra. Necesita Bluetooth 4.0+ (BLE).
 *   MODO_WIFI : se conecta a tu WiFi (secrets.h) y envía el movimiento por UDP.
 *               En el PC hay que ejecutar el script  pc/mause_pc.py
 *
 * Uso:
 *   1. Al encender, deja el mouse QUIETO ~2 s (calibra el giroscopio).
 *   2. BLE: empareja "Mause ESP32".  WiFi: ejecuta  python3 pc/mause_pc.py
 *   3. Mantén los dos botones pulsados 2 s para recalibrar.
 */

#define MODO_BLE  0
#define MODO_WIFI 1

#define MODO MODO_BLE       // <<< cambia aquí el modo

#include <Wire.h>

#if MODO == MODO_BLE
  #include <BLEDevice.h>
  #include <BLEServer.h>
  #include <BLEHIDDevice.h>
  #include <HIDTypes.h>
  #include <BLESecurity.h>
#elif MODO == MODO_WIFI
  #include <WiFi.h>
  #include <WiFiUdp.h>
  #include "secrets.h"      // define WIFI_SSID y WIFI_PASS
#else
  #error "MODO no válido"
#endif

// ---------------- Pines ----------------
#define PIN_SDA        5   // D4
#define PIN_SCL        6   // D5
#define PIN_BTN_IZQ    1   // D0
#define PIN_BTN_DER    2   // D1

// ---------------- Ajustes ----------------
const char*  NOMBRE         = "Mause ESP32";
// Sensibilidad por eje: píxeles por (°/s) en cada ciclo. Súbelas para más velocidad.
// El eje vertical es más alta porque la muñeca tiene menos recorrido arriba/abajo.
const float  SENSIBILIDAD_X = 0.12f;
const float  SENSIBILIDAD_Y = 0.20f;
// Aceleración: movimientos lentos = precisos, movimientos rápidos = el cursor llega lejos.
const float  ACELERACION    = 1.2f;   // 0 = sin aceleración
const float  VEL_REFERENCIA = 120.0f; // °/s a la que la aceleración ya da el doble (con ACELERACION=1)
const float  ACEL_MAXIMA    = 3.0f;   // multiplicador máximo
const float  ZONA_MUERTA    = 1.5f;   // °/s (sobre la velocidad total) que se ignoran (temblor)
const float  SUAVIZADO      = 0.5f;   // 0 = sin filtro, 0.9 = muy suave (más lento en reaccionar)
const uint32_t PERIODO_MS   = 10;     // 100 Hz

// Mapeo de ejes del giroscopio -> movimiento del cursor.
// 0 = eje X, 1 = eje Y, 2 = eje Z del MPU-6050.
// Si el cursor se mueve en el eje equivocado o al revés, cambia estos valores.
const int  EJE_CURSOR_X     = 2;      // giro horizontal (yaw)
const int  EJE_CURSOR_Y     = 0;      // inclinación arriba/abajo (pitch)
const bool INVERTIR_X       = true;
const bool INVERTIR_Y       = false;

// ---------------- MPU-6050 ----------------
#define MPU_ADDR       0x68
#define MPU_PWR_MGMT_1 0x6B
#define MPU_CONFIG     0x1A
#define MPU_GYRO_CFG   0x1B
#define MPU_GYRO_XOUT  0x43
const float GYRO_LSB_POR_GRADO = 131.0f;  // rango ±250 °/s

float offsetGyro[3] = {0, 0, 0};
float gyroFiltrado[3] = {0, 0, 0};
float restoX = 0, restoY = 0;   // acumula fracciones de píxel

volatile bool conectado = false;
bool verEjes = false;   // diagnóstico: enviar 'e' por el Monitor Serie

struct Boton {
  uint8_t  pin;
  bool     estado;        // true = pulsado (estable)
  bool     lecturaPrevia;
  uint32_t tCambio;
};
void enviarReporte(uint8_t botones, int8_t dx, int8_t dy, int8_t rueda);

// =====================================================================
//                              BLE HID
// =====================================================================
#if MODO == MODO_BLE
static const uint8_t REPORT_MAP[] = {
  USAGE_PAGE(1),       0x01,  // Generic Desktop
  USAGE(1),            0x02,  // Mouse
  COLLECTION(1),       0x01,  // Application
    REPORT_ID(1),      0x01,
    USAGE(1),          0x01,  // Pointer
    COLLECTION(1),     0x00,  // Physical
      USAGE_PAGE(1),   0x09,  // 3 botones
      USAGE_MINIMUM(1),0x01,
      USAGE_MAXIMUM(1),0x03,
      LOGICAL_MINIMUM(1),0x00,
      LOGICAL_MAXIMUM(1),0x01,
      REPORT_SIZE(1),  0x01,
      REPORT_COUNT(1), 0x03,
      HIDINPUT(1),     0x02,
      REPORT_SIZE(1),  0x05,  // relleno 5 bits
      REPORT_COUNT(1), 0x01,
      HIDINPUT(1),     0x03,
      USAGE_PAGE(1),   0x01,  // X, Y, rueda
      USAGE(1),        0x30,
      USAGE(1),        0x31,
      USAGE(1),        0x38,
      LOGICAL_MINIMUM(1),0x81,
      LOGICAL_MAXIMUM(1),0x7F,
      REPORT_SIZE(1),  0x08,
      REPORT_COUNT(1), 0x03,
      HIDINPUT(1),     0x06,
    END_COLLECTION(0),
  END_COLLECTION(0)
};

BLEHIDDevice*      hid = nullptr;
BLECharacteristic* reporteEntrada = nullptr;

class CallbacksServidor : public BLEServerCallbacks {
  void onConnect(BLEServer* servidor) {
    conectado = true;
    Serial.println("[BLE] Conectado");
  }
  void onDisconnect(BLEServer* servidor) {
    conectado = false;
    Serial.println("[BLE] Desconectado, anunciando de nuevo...");
    delay(100);
    BLEDevice::startAdvertising();
  }
};

void iniciarComunicacion() {
  BLEDevice::init(NOMBRE);
  BLEServer* servidor = BLEDevice::createServer();
  servidor->setCallbacks(new CallbacksServidor());

  hid = new BLEHIDDevice(servidor);
  reporteEntrada = hid->inputReport(1);
  hid->manufacturer()->setValue("Baycodec");
  hid->pnp(0x02, 0xE502, 0xA111, 0x0210);
  hid->hidInfo(0x00, 0x02);
  hid->reportMap((uint8_t*)REPORT_MAP, sizeof(REPORT_MAP));
  hid->startServices();
  hid->setBatteryLevel(100);

  BLESecurity::setCapability(ESP_IO_CAP_NONE);
  BLESecurity::setAuthenticationMode(true, false, true);  // bonding, sin MITM, secure connections

  BLEAdvertising* anuncio = servidor->getAdvertising();
  anuncio->setAppearance(HID_MOUSE);
  anuncio->addServiceUUID(hid->hidService()->getUUID());
  anuncio->start();
  Serial.println("[BLE] Anunciando como \"" + String(NOMBRE) + "\"");
}

void atenderComunicacion() {}

void enviarReporte(uint8_t botones, int8_t dx, int8_t dy, int8_t rueda) {
  if (!conectado || reporteEntrada == nullptr) return;
  uint8_t r[4] = {botones, (uint8_t)dx, (uint8_t)dy, (uint8_t)rueda};
  reporteEntrada->setValue(r, sizeof(r));
  reporteEntrada->notify();
}

// =====================================================================
//                              WiFi UDP
// =====================================================================
#elif MODO == MODO_WIFI
/*
 * Protocolo:
 *   ESP32 -> PC (puerto 4210): 8 bytes  'M','S', seq_lo, seq_hi, botones, dx, dy, rueda
 *   PC -> ESP32 (puerto 4211): "MAUSE_ACK"
 * Mientras no conoce al PC, el ESP32 envía por broadcast. Cuando el PC
 * responde, envía directo a su IP. Si deja de recibir ACK 3 s, vuelve a broadcast.
 */
const uint16_t PUERTO_PC  = 4210;
const uint16_t PUERTO_ESP = 4211;

WiFiUDP   udp;
IPAddress ipPC;
bool      pcConocido = false;
uint32_t  tUltimoAck = 0;
uint32_t  tUltimoEnvio = 0;
uint16_t  secuencia = 0;
uint8_t   ultimosBotones = 0;
bool      wifiEstabaConectado = false;

void iniciarComunicacion() {
  WiFi.mode(WIFI_STA);
  WiFi.setHostname("mause-esp32");
  WiFi.setSleep(false);              // menos latencia (consume más batería)
  WiFi.setAutoReconnect(true);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.printf("[WiFi] Conectando a \"%s\"", WIFI_SSID);
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 20000) {
    delay(250);
    Serial.print(".");
  }
  Serial.println();
  wifiEstabaConectado = (WiFi.status() == WL_CONNECTED);
  if (wifiEstabaConectado) {
    Serial.printf("[WiFi] Conectado. IP: %s  RSSI: %d dBm\n",
                  WiFi.localIP().toString().c_str(), WiFi.RSSI());
  } else {
    Serial.println("[WiFi] Aún sin conexión, se seguirá intentando en segundo plano");
  }
  udp.begin(PUERTO_ESP);
}

void atenderComunicacion() {
  conectado = (WiFi.status() == WL_CONNECTED);
  if (conectado != wifiEstabaConectado) {
    wifiEstabaConectado = conectado;
    if (conectado) {
      Serial.printf("[WiFi] Conectado. IP: %s\n", WiFi.localIP().toString().c_str());
    } else {
      Serial.println("[WiFi] Conexión perdida, reintentando...");
      pcConocido = false;
    }
  }
  if (!conectado) return;

  // ACK del PC
  int n = udp.parsePacket();
  while (n > 0) {
    char buf[16] = {0};
    udp.read(buf, sizeof(buf) - 1);
    if (strncmp(buf, "MAUSE_ACK", 9) == 0) {
      if (!pcConocido || udp.remoteIP() != ipPC) {
        Serial.printf("[WiFi] PC encontrado en %s\n", udp.remoteIP().toString().c_str());
      }
      ipPC = udp.remoteIP();
      pcConocido = true;
      tUltimoAck = millis();
    }
    n = udp.parsePacket();
  }
  if (pcConocido && millis() - tUltimoAck > 3000) {
    pcConocido = false;
    Serial.println("[WiFi] PC sin respuesta, buscando por broadcast...");
  }

  // Keepalive cada 500 ms aunque no haya movimiento
  if (millis() - tUltimoEnvio > 500) {
    enviarReporte(ultimosBotones, 0, 0, 0);
  }
}

void enviarReporte(uint8_t botones, int8_t dx, int8_t dy, int8_t rueda) {
  ultimosBotones = botones;
  if (!conectado) return;
  secuencia++;
  uint8_t p[8] = {'M', 'S', (uint8_t)(secuencia & 0xFF), (uint8_t)(secuencia >> 8),
                  botones, (uint8_t)dx, (uint8_t)dy, (uint8_t)rueda};
  IPAddress destino = pcConocido ? ipPC : WiFi.broadcastIP();
  udp.beginPacket(destino, PUERTO_PC);
  udp.write(p, sizeof(p));
  udp.endPacket();
  tUltimoEnvio = millis();
}
#endif

// =====================================================================
//                              Botones
// =====================================================================
Boton btnIzq = {PIN_BTN_IZQ, false, false, 0};
Boton btnDer = {PIN_BTN_DER, false, false, 0};

void actualizarBoton(Boton& b) {
  bool lectura = (digitalRead(b.pin) == LOW);   // a GND = pulsado
  if (lectura != b.lecturaPrevia) {
    b.lecturaPrevia = lectura;
    b.tCambio = millis();
  }
  if (millis() - b.tCambio > 20) b.estado = lectura;  // antirrebote 20 ms
}

// =====================================================================
//                              MPU-6050
// =====================================================================
void mpuEscribir(uint8_t reg, uint8_t valor) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  Wire.write(valor);
  Wire.endTransmission();
}

bool mpuLeerGyro(float g[3]) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(MPU_GYRO_XOUT);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((uint8_t)MPU_ADDR, (uint8_t)6) != 6) return false;
  for (int i = 0; i < 3; i++) {
    int16_t crudo = (Wire.read() << 8) | Wire.read();
    g[i] = crudo / GYRO_LSB_POR_GRADO;
  }
  return true;
}

bool mpuIniciar() {
  Wire.beginTransmission(MPU_ADDR);
  if (Wire.endTransmission() != 0) return false;
  mpuEscribir(MPU_PWR_MGMT_1, 0x01);  // despertar, reloj del giroscopio X
  delay(100);
  mpuEscribir(MPU_CONFIG, 0x03);      // filtro paso bajo ~44 Hz
  mpuEscribir(MPU_GYRO_CFG, 0x00);    // ±250 °/s
  return true;
}

void calibrarGyro() {
  Serial.println("[MPU] Calibrando... no muevas el mouse");
  const int N = 400;
  float suma[3] = {0, 0, 0}, g[3];
  int validas = 0;
  for (int i = 0; i < N; i++) {
    if (mpuLeerGyro(g)) {
      for (int k = 0; k < 3; k++) suma[k] += g[k];
      validas++;
    }
    delay(4);
  }
  if (validas > 0) {
    for (int k = 0; k < 3; k++) offsetGyro[k] = suma[k] / validas;
  }
  for (int k = 0; k < 3; k++) gyroFiltrado[k] = 0;
  restoX = restoY = 0;
  Serial.printf("[MPU] Offset: X=%.2f Y=%.2f Z=%.2f\n",
                offsetGyro[0], offsetGyro[1], offsetGyro[2]);
}

// =====================================================================
//                              Setup / Loop
// =====================================================================
void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.printf("\n=== Mause ESP32 (%s) ===\n", MODO == MODO_BLE ? "Bluetooth LE" : "WiFi UDP");

  pinMode(PIN_BTN_IZQ, INPUT_PULLUP);
  pinMode(PIN_BTN_DER, INPUT_PULLUP);

  Wire.begin(PIN_SDA, PIN_SCL);
  Wire.setClock(400000);

  while (!mpuIniciar()) {
    Serial.println("[MPU] No se encuentra el MPU-6050 (revisa SDA=D4, SCL=D5, VCC, GND)");
    delay(1000);
  }
  Serial.println("[MPU] OK");
  calibrarGyro();

  iniciarComunicacion();
}

void loop() {
  static uint32_t tAnterior = 0;
  static uint8_t  botonesAnteriores = 0;
  static uint32_t tAmbosPulsados = 0;

  atenderComunicacion();

  // Comando por puerto serie: 'e' activa/desactiva el modo de ver ejes
  while (Serial.available()) {
    char c = Serial.read();
    if (c == 'e' || c == 'E') {
      verEjes = !verEjes;
      Serial.println(verEjes ? "[DIAG] Ver ejes ON" : "[DIAG] Ver ejes OFF");
    }
  }

  uint32_t ahora = millis();
  if (ahora - tAnterior < PERIODO_MS) return;
  tAnterior = ahora;

  // --- Botones ---
  actualizarBoton(btnIzq);
  actualizarBoton(btnDer);
  uint8_t botones = (btnIzq.estado ? 0x01 : 0) | (btnDer.estado ? 0x02 : 0);

  // Ambos botones 2 s -> recalibrar
  if (btnIzq.estado && btnDer.estado) {
    if (tAmbosPulsados == 0) tAmbosPulsados = ahora;
    if (ahora - tAmbosPulsados > 2000) {
      enviarReporte(0, 0, 0, 0);   // soltar botones en el host
      delay(500);                  // tiempo para dejarlo quieto
      calibrarGyro();
      tAmbosPulsados = 0;
      botonesAnteriores = 0;
      while (digitalRead(PIN_BTN_IZQ) == LOW || digitalRead(PIN_BTN_DER) == LOW) delay(10);
      return;
    }
  } else {
    tAmbosPulsados = 0;
  }

  // --- Giroscopio ---
  float g[3];
  if (!mpuLeerGyro(g)) return;
  for (int k = 0; k < 3; k++) {
    float v = g[k] - offsetGyro[k];
    gyroFiltrado[k] = SUAVIZADO * gyroFiltrado[k] + (1.0f - SUAVIZADO) * v;
  }

  // Modo diagnóstico: envía las 3 velocidades por el puerto serie
  if (verEjes) {
    static uint8_t div = 0;
    if (++div >= 2) {   // 50 Hz
      div = 0;
      Serial.printf("G,%.1f,%.1f,%.1f\n", gyroFiltrado[0], gyroFiltrado[1], gyroFiltrado[2]);
    }
  }

  float vx = gyroFiltrado[EJE_CURSOR_X] * (INVERTIR_X ? -1 : 1);
  float vy = gyroFiltrado[EJE_CURSOR_Y] * (INVERTIR_Y ? -1 : 1);

  // Zona muerta sobre la velocidad total (no por eje) y suave: no corta los
  // movimientos diagonales ni los verticales lentos, y no da saltos al salir de ella.
  float vel = sqrtf(vx * vx + vy * vy);
  if (vel <= ZONA_MUERTA) {
    vx = vy = 0;
  } else {
    float escala = (vel - ZONA_MUERTA) / vel;
    vx *= escala;
    vy *= escala;
    vel -= ZONA_MUERTA;
  }

  // Aceleración
  float acel = 1.0f + ACELERACION * (vel / VEL_REFERENCIA);
  if (acel > ACEL_MAXIMA) acel = ACEL_MAXIMA;

  restoX += vx * SENSIBILIDAD_X * acel;
  restoY += vy * SENSIBILIDAD_Y * acel;
  int dx = constrain((int)restoX, -127, 127);
  int dy = constrain((int)restoY, -127, 127);
  restoX -= dx;
  restoY -= dy;

  if (dx != 0 || dy != 0 || botones != botonesAnteriores) {
    enviarReporte(botones, dx, dy, 0);
    botonesAnteriores = botones;
  }
}
