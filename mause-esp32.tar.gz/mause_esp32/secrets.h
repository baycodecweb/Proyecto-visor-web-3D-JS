// Credenciales WiFi (no compartas este archivo)
#pragma once
#define WIFI_SSID "Servidor07"
#define WIFI_PASS "baycodec"
