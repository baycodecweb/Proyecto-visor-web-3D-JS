#!/usr/bin/env python3
"""
Mause ESP32 - receptor WiFi para el PC (Linux / X11).

Recibe por UDP el movimiento y los clics del ESP32 y mueve el cursor del
sistema usando la extensión XTest de X11 (no necesita instalar nada).

Uso:
    python3 mause_pc.py              # mueve el cursor
    python3 mause_pc.py --prueba     # solo muestra lo que llega, no mueve nada
    python3 mause_pc.py --escala 1.5 # multiplica la velocidad del cursor

Protocolo (ver firmware):
    ESP32 -> PC  puerto 4210: 'M','S', seq_lo, seq_hi, botones, dx, dy, rueda
    PC -> ESP32  (al remitente): b"MAUSE_ACK"
"""
import argparse
import collections
import ctypes
import socket
import struct
import sys
import time

PUERTO = 4210
BOTONES_X11 = {0x01: 1, 0x02: 3, 0x04: 2}   # izq, der, medio


class CursorX11:
    def __init__(self):
        self.x11 = ctypes.cdll.LoadLibrary("libX11.so.6")
        self.xtst = ctypes.cdll.LoadLibrary("libXtst.so.6")
        self.x11.XOpenDisplay.restype = ctypes.c_void_p
        self.x11.XOpenDisplay.argtypes = [ctypes.c_char_p]
        self.x11.XFlush.argtypes = [ctypes.c_void_p]
        self.xtst.XTestFakeRelativeMotionEvent.argtypes = [
            ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_ulong]
        self.xtst.XTestFakeButtonEvent.argtypes = [
            ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_ulong]
        self.dpy = self.x11.XOpenDisplay(None)
        if not self.dpy:
            sys.exit("No se pudo abrir la pantalla X11 (¿variable DISPLAY?).")

    def mover(self, dx, dy):
        self.xtst.XTestFakeRelativeMotionEvent(self.dpy, dx, dy, 0)

    def boton(self, numero, pulsado):
        self.xtst.XTestFakeButtonEvent(self.dpy, numero, 1 if pulsado else 0, 0)

    def flush(self):
        self.x11.XFlush(self.dpy)


def main():
    ap = argparse.ArgumentParser(description="Receptor WiFi del Mause ESP32")
    ap.add_argument("--prueba", action="store_true", help="no mueve el cursor, solo muestra datos")
    ap.add_argument("--escala", type=float, default=1.0, help="multiplicador de velocidad")
    args = ap.parse_args()

    cursor = None if args.prueba else CursorX11()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.bind(("", PUERTO))
    sock.settimeout(1.0)
    print(f"Esperando al Mause ESP32 en UDP {PUERTO}...  (Ctrl+C para salir)")

    vistos = collections.deque(maxlen=16)   # descarta duplicados (p. ej. broadcast por 2 interfaces)
    botones_prev = 0
    ultimo_ack = 0.0
    ultimo_paquete = 0.0
    origen_prev = None
    resto_x = resto_y = 0.0
    paquetes = 0
    t_stats = time.time()

    try:
        while True:
            try:
                datos, origen = sock.recvfrom(64)
            except socket.timeout:
                if ultimo_paquete and time.time() - ultimo_paquete > 3:
                    print("Sin datos del ESP32...")
                    ultimo_paquete = 0.0
                    if cursor and botones_prev:   # soltar botones si se corta
                        for bit, num in BOTONES_X11.items():
                            if botones_prev & bit:
                                cursor.boton(num, False)
                        cursor.flush()
                        botones_prev = 0
                continue

            if len(datos) != 8 or datos[:2] != b"MS":
                continue
            seq, botones, dx, dy, rueda = struct.unpack("<HBbbb", datos[2:])
            clave = (origen[0], seq)
            if clave in vistos:
                continue
            vistos.append(clave)

            ahora = time.time()
            ultimo_paquete = ahora
            paquetes += 1
            if origen[0] != origen_prev:
                print(f"Conectado con el ESP32 en {origen[0]}")
                origen_prev = origen[0]

            # Responder para que el ESP32 sepa nuestra IP (máx. 2 veces por segundo)
            if ahora - ultimo_ack > 0.5:
                sock.sendto(b"MAUSE_ACK", origen)
                ultimo_ack = ahora

            if args.prueba:
                if dx or dy or botones != botones_prev or rueda:
                    print(f"seq={seq:5d} botones={botones:03b} dx={dx:4d} dy={dy:4d} rueda={rueda}")
                botones_prev = botones
            else:
                resto_x += dx * args.escala
                resto_y += dy * args.escala
                mx, my = int(resto_x), int(resto_y)
                resto_x -= mx
                resto_y -= my
                if mx or my:
                    cursor.mover(mx, my)
                cambios = botones ^ botones_prev
                for bit, num in BOTONES_X11.items():
                    if cambios & bit:
                        cursor.boton(num, bool(botones & bit))
                botones_prev = botones
                if rueda:
                    num = 4 if rueda > 0 else 5
                    for _ in range(abs(rueda)):
                        cursor.boton(num, True)
                        cursor.boton(num, False)
                cursor.flush()

            if ahora - t_stats > 10:
                print(f"[{paquetes / (ahora - t_stats):.0f} paquetes/s]")
                paquetes = 0
                t_stats = ahora
    except KeyboardInterrupt:
        print("\nSaliendo.")


if __name__ == "__main__":
    main()
