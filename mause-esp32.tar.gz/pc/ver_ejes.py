#!/usr/bin/env python3
"""
Diagnóstico de ejes del Mause ESP32 (por cable USB).

Le pide al ESP32 las velocidades del giroscopio y te dice qué eje del
MPU-6050 se mueve con cada gesto. Sirve para configurar EJE_CURSOR_X/Y
e INVERTIR_X/Y en el firmware.

Uso:  python3 pc/ver_ejes.py            (puerto por defecto /dev/ttyACM0)
      python3 pc/ver_ejes.py /dev/ttyACM1
"""
import sys
import time

import serial

PUERTO = sys.argv[1] if len(sys.argv) > 1 else "/dev/ttyACM0"
NOMBRES = ["X (0)", "Y (1)", "Z (2)"]
GESTOS = [
    ("HORIZONTAL", "gira el mouse a IZQUIERDA y DERECHA varias veces (como decir 'no')"),
    ("VERTICAL", "inclina el mouse ARRIBA y ABAJO varias veces (como decir 'sí')"),
]
SEGUNDOS = 6


def leer(s, segundos):
    datos = []
    fin = time.time() + segundos
    while time.time() < fin:
        linea = s.readline().decode(errors="replace").strip()
        if linea.startswith("G,"):
            try:
                datos.append([float(v) for v in linea[2:].split(",")])
            except ValueError:
                pass
    return datos


def analizar(datos):
    energia = [sum(m[k] ** 2 for m in datos) for k in range(3)]
    eje = max(range(3), key=lambda k: energia[k])
    total = sum(energia) or 1
    # Signo del primer movimiento fuerte en ese eje
    pico = max(abs(m[eje]) for m in datos) if datos else 0
    primero = next((m[eje] for m in datos if abs(m[eje]) > pico * 0.5), 0)
    return eje, [100 * e / total for e in energia], primero


def main():
    s = serial.Serial(PUERTO, 115200, timeout=0.2)
    time.sleep(0.3)
    s.reset_input_buffer()
    s.write(b"e")
    time.sleep(0.3)
    if not any(l.startswith(b"G,") for l in s.readlines()):
        s.write(b"e")   # estaba ya activo y lo apagamos; volver a encender
        time.sleep(0.3)

    resultados = {}
    try:
        for nombre, instruccion in GESTOS:
            print(f"\n>>> Prepárate: {instruccion}")
            for n in (3, 2, 1):
                print(f"    {n}...", flush=True)
                time.sleep(1)
            print(f"    ¡AHORA! ({SEGUNDOS} s)", flush=True)
            datos = leer(s, SEGUNDOS)
            if not datos:
                print("No llegan datos. ¿El firmware nuevo está subido y el ESP32 conectado por USB?")
                return
            eje, pct, primero = analizar(datos)
            resultados[nombre] = (eje, primero)
            print("    Reparto del movimiento: " +
                  "  ".join(f"{NOMBRES[k]}={pct[k]:.0f}%" for k in range(3)))
            print(f"    => {nombre}: eje {NOMBRES[eje]}  ({pct[eje]:.0f}% del movimiento)")
            if pct[eje] < 60:
                print("    (aviso: el gesto se repartió entre varios ejes; intenta un movimiento más limpio)")
    finally:
        s.write(b"e")
        s.close()

    ex = resultados["HORIZONTAL"][0]
    ey = resultados["VERTICAL"][0]
    print("\n================ RESULTADO ================")
    print(f"const int  EJE_CURSOR_X     = {ex};")
    print(f"const int  EJE_CURSOR_Y     = {ey};")
    if ex == ey:
        print("¡Ojo! Los dos gestos usaron el mismo eje. Repite la prueba con movimientos más limpios.")
    print("(La dirección/inversión se comprueba luego moviendo el cursor.)")


if __name__ == "__main__":
    main()
